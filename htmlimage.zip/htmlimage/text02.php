<!DOCTYPE HTML>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	<script src="https://files.codepedia.info/files/uploads/iScripts/html2canvas.js"></script>
<style>
#div1 #drag1{
	background:transparent;
	border: none;
	font-size: 30px;
	color: #ededed;
	text-align: center;
}
#div1 #drag3{
	background:transparent;
	border: none;
	font-size: 15px;
	margin-top: 60px;
	color: #ededed;
	text-align: center;
}
#div1 {
  width: 400px;
  height: 400px;
  padding: 10px;
  border: 1px solid #aaaaaa;
}
</style>
<script>
function allowDrop(ev) {
  ev.preventDefault();
}

function drag(ev) {
  ev.dataTransfer.setData("text", ev.target.id);
}

function drop(ev) {
  ev.preventDefault();
  var data = ev.dataTransfer.getData("text");
  ev.target.appendChild(document.getElementById(data));
}
</script>
</head>
<body>

<p>Satirtha Test:</p>

<div class="container">
	<div class="row">
		<div class="col-sm-8 ">
			<div id="html-content-holder">
				<div id="div1" ondrop="drop(event)" ondragover="allowDrop(event)" style="background-image: url('2.jpg');"></div>
			</div>
		</div>
		<div class="col-sm-4">
			<!-- <img id="drag1" src="img_logo.gif" draggable="true" ondragstart="drag(event)" width="336" height="69">
 -->			<input type="text" id="drag1" draggable="true" class="form-control" ondragstart="drag(event)" name=""><br>
			<input type="text" id="drag2" draggable="true" class="form-control" ondragstart="drag(event)" name=""><br>
			<textarea name="text" id="drag3" value="test" class="form-control" draggable="true" ondragstart="drag(event)" name=""></textarea>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<input id="btn-Preview-Image" type="button" value="Preview"/>
			<a id="btn-Convert-Html2Image" href="#">Download</a>
			<br/>
			<h3>Preview :</h3>
			<div id="previewImage">
			</div>
		</div>
	</div>
</div>
<script>
	$(document).ready(function(){

		
	var element = $("#html-content-holder"); // global variable
	var getCanvas; // global variable
	 
	    $("#btn-Preview-Image").on('click', function () {
	         html2canvas(element, {
	         onrendered: function (canvas) {
	                $("#previewImage").append(canvas);
	                getCanvas = canvas;
	             }
	         });
	    });

		$("#btn-Convert-Html2Image").on('click', function () {
	    var imgageData = getCanvas.toDataURL("image/jpg");

	    // Now browser starts downloading it instead of just showing it
	    var newData = imgageData.replace(/^data:image\/jpg/, "data:application/octet-stream");
	    $("#btn-Convert-Html2Image").attr("download", "my_data.jpg").attr("href", newData);
		});

	});

</script>
</body>
</html>
