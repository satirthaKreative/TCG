<!DOCTYPE HTML>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	<script src="https://files.codepedia.info/files/uploads/iScripts/html2canvas.js"></script>
<style >
/*#div1 #drag1{
	background:transparent;
	border: none;
	font-size: 30px;
	color: #ededed;
	text-align: center;
}*/
/*#div1 #drag3{
	background:transparent;
	border: none;
	font-size: 15px;
	color: #ededed;
	text-align: center;
}*/
#div1 {
  width: 400px;
  height: 400px;
  padding: 10px;
  border: 1px solid #aaaaaa;
}
</style>
<script>
function allowDrop(ev) {
  ev.preventDefault();
}

// function drag(ev) {
//   ev.dataTransfer.setData("text", ev.target.id);
// }


function drop(ev) {
  ev.preventDefault();
  var data = ev.dataTransfer.getData("text");
  ev.target.appendChild(document.getElementById(data));
}


</script>
</head>
<body >

<p>Satirtha Test:</p>
<div class="container" >
	<div class="row">
		<div class="col-sm-8 ">
			<section  id="html-content-holder" >
				<div id="div1" ondrop="drop(event)" ondragover="allowDrop(event)" style="background-image: url('2.jpg');">
					<input type="text" id="drag1" name=""/>	<br/>
					<textarea name="text" id="drag3" rows="10" value="test" ></textarea>
					<img id="drag4" src="Birthday-Hat-PNG-Picture.png"    width="200" height="150" />
					<input type="text" id="drag2" draggable="true" name="" /> <br>
				</div>
					
			</section>
		</div>
		<div class="col-sm-4">
			<!-- <img id="drag1" src="img_logo.gif" draggable="true" ondragstart="drag(event)" width="336" height="69">
 -->	
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<input id="btn-Preview-Image" type="button" value="Preview"/>
			<a id="btn-Convert-Html2Image" href="#">Download</a>
			<br/>
			<h3>Preview :</h3>
			<div id="previewImage">
			</div>
		</div>
	</div>
</div>
<script>
	$(document).ready(function(){

		
	var element = $("body"); // global variable
	var getCanvas; // global variable
	 
	    $("#btn-Preview-Image").on('click', function () {
	         html2canvas(element, {
	         onrendered: function (canvas) {
	                $("#previewImage").append(canvas);
	                getCanvas = canvas;
	             }
	         });
	    });

		$("#btn-Convert-Html2Image").on('click', function () {
	    var imgageData = getCanvas.toDataURL("image/png");

	    // Now browser starts downloading it instead of just showing it
	    var newData = imgageData.replace(/^data:image\/png/, "data:application/octet-stream");
	    $("#btn-Convert-Html2Image").attr("download", "my_data.png").attr("href", newData);
		});

	});

</script>

<script>
	$(function(){
		$("#drag1").keypress(function(event){
			$("#drag1").css("background", "transparent");
			$("#drag1").css("border", "none");
			$("#drag1").css("font-size", "30px");
			$("#drag1").css("color", "rgb(12, 162, 234)");
			$("#drag1").css("text-align", "center");
		});
		$("#drag2").keypress(function(event){
			$("#drag2").css("background", "transparent");
			$("#drag2").css("border", "none");
			$("#drag2").css("font-size", "30px");
			$("#drag2").css("color", "red");
			$("#drag2").css("text-align", "center");
		});
		$("#drag3").keypress(function(event){
			$("#drag3").css("background", "transparent");
			$("#drag3").css("border", "none");
			$("#drag3").css("font-size", "20px");
			$("#drag3").css("color", "#fff");
			$("#drag3").css("text-align", "center");
		});
		$("#drag3").change(function(event){
			$("#drag3").css("background", "transparent");
			$("#drag3").css("border", "none");
			$("#drag3").css("font-size", "18px");
			$("#drag3").css("color", "#fff");
			$("#drag3").css("text-align", "center");
		});
	});
</script>

<script>
   let currentDroppable = null;

   drag4.onmousedown = function(event) {

     let shiftX = event.clientX - drag4.getBoundingClientRect().left;
     let shiftY = event.clientY - drag4.getBoundingClientRect().top;

     drag4.style.position = 'absolute';
     drag4.style.zIndex = 1000;
     $("body").append(drag4);
     // $("section#html-content-holder").append(drag2);
     moveAt(event.pageX, event.pageY);

     function moveAt(pageX, pageY) {
       drag4.style.left = pageX - shiftX + 'px';
       drag4.style.top = pageY - shiftY + 'px';
     }

     function onMouseMove(event) {
       moveAt(event.pageX, event.pageY);

       drag4.hidden = true;
       let elemBelow = document.elementFromPoint(event.clientX, event.clientY);
       drag4.hidden = false;

       if (!elemBelow) return;

       let droppableBelow = elemBelow.closest('.droppable');
       if (currentDroppable != droppableBelow) {
         if (currentDroppable) { // null when we were not over a droppable before this event
           leaveDroppable(currentDroppable);
         }
         currentDroppable = droppableBelow;
         if (currentDroppable) { // null if we're not coming over a droppable now
           // (maybe just left the droppable)
           enterDroppable(currentDroppable);
         }
       }
     }

     document.addEventListener('mousemove', onMouseMove);

     drag4.onmouseup = function() {
       document.removeEventListener('mousemove', onMouseMove);
       drag4.onmouseup = null;
     };

   };

   // function enterDroppable(elem) {
   //   elem.style.background = 'pink';
   // }

   // function leaveDroppable(elem) {
   //   elem.style.background = '';
   // }

   drag4.ondragstart = function() {
     return false;
   };
 </script>
 <script>
 	let currentDroppable1 = null;
 	drag3.onmousedown = function(event) {

     let shiftX = event.clientX - drag3.getBoundingClientRect().left;
     let shiftY = event.clientY - drag3.getBoundingClientRect().top;

     drag3.style.position = 'absolute';
     drag3.style.zIndex = 1000;
     $("body").append(drag3);
     // $("section#html-content-holder").append(drag2);
     moveAt(event.pageX, event.pageY);

     function moveAt(pageX, pageY) {
       drag3.style.left = pageX - shiftX + 'px';
       drag3.style.top = pageY - shiftY + 'px';
     }

     function onMouseMove(event) {
       moveAt(event.pageX, event.pageY);

       drag3.hidden = true;
       let elemBelow = document.elementFromPoint(event.clientX, event.clientY);
       drag3.hidden = false;

       if (!elemBelow) return;

       let droppableBelow = elemBelow.closest('.droppable');
       if (currentDroppable1 != droppableBelow) {
         if (currentDroppable1) { // null when we were not over a droppable before this event
           leaveDroppable(currentDroppable1);
         }
         currentDroppable1= droppableBelow;
         if (currentDroppable1) { // null if we're not coming over a droppable now
           // (maybe just left the droppable)
           enterDroppable(currentDroppable1);
         }
       }
     }

     document.addEventListener('mousemove', onMouseMove);

     drag3.onmouseup = function() {
       document.removeEventListener('mousemove', onMouseMove);
       drag3.onmouseup = null;
     };

   };

   // function enterDroppable(elem) {
   //   elem.style.background = 'pink';
   // }

   // function leaveDroppable(elem) {
   //   elem.style.background = '';
   // }

   drag3.ondragstart = function() {
     return false;
   };
 </script>
 <script>
 	let currentDroppable2 = null;
 	drag2.onmousedown = function(event) {

     let shiftX = event.clientX - drag2.getBoundingClientRect().left;
     let shiftY = event.clientY - drag2.getBoundingClientRect().top;

     drag2.style.position = 'absolute';
     drag2.style.zIndex = 1000;
     $("body").append(drag2);
     // $("section#html-content-holder").append(drag2);
     moveAt(event.pageX, event.pageY);

     function moveAt(pageX, pageY) {
       drag2.style.left = pageX - shiftX + 'px';
       drag2.style.top = pageY - shiftY + 'px';
     }

     function onMouseMove(event) {
       moveAt(event.pageX, event.pageY);

       drag2.hidden = true;
       let elemBelow = document.elementFromPoint(event.clientX, event.clientY);
       drag2.hidden = false;

       if (!elemBelow) return;

       let droppableBelow = elemBelow.closest('.droppable');
       if (currentDroppable2 != droppableBelow) {
         if (currentDroppable2) { // null when we were not over a droppable before this event
           leaveDroppable(currentDroppable2);
         }
         currentDroppable2 = droppableBelow;
         if (currentDroppable2) { // null if we're not coming over a droppable now
           // (maybe just left the droppable)
           enterDroppable(currentDroppable2);
         }
       }
     }

     document.addEventListener('mousemove', onMouseMove);

     drag2.onmouseup = function() {
       document.removeEventListener('mousemove', onMouseMove);
       drag2.onmouseup = null;
     };

   };

   // function enterDroppable(elem) {
   //   elem.style.background = 'pink';
   // }

   // function leaveDroppable(elem) {
   //   elem.style.background = '';
   // }

   drag2.ondragstart = function() {
     return false;
   };
 </script>
  <script>
  	let currentDroppable3 = null;
 	drag1.onmousedown = function(event) {

     let shiftX = event.clientX - drag1.getBoundingClientRect().left;
     let shiftY = event.clientY - drag1.getBoundingClientRect().top;

     drag1.style.position = 'absolute';
     drag1.style.zIndex = 1000;
     $("body").append(drag1);
     // $("section#html-content-holder").append(drag2);
     moveAt(event.pageX, event.pageY);

     function moveAt(pageX, pageY) {
       drag1.style.left = pageX - shiftX + 'px';
       drag1.style.top = pageY - shiftY + 'px';
     }

     function onMouseMove(event) {
       moveAt(event.pageX, event.pageY);

       drag1.hidden = true;
       let elemBelow = document.elementFromPoint(event.clientX, event.clientY);
       drag1.hidden = false;

       if (!elemBelow) return;

       let droppableBelow = elemBelow.closest('.droppable');
       if (currentDroppable3 != droppableBelow) {
         if (currentDroppable3) { // null when we were not over a droppable before this event
           leaveDroppable(currentDroppable3);
         }
         currentDroppable3 = droppableBelow;
         if (currentDroppable3) { // null if we're not coming over a droppable now
           // (maybe just left the droppable)
           enterDroppable(currentDroppable3);
         }
       }
     }

     document.addEventListener('mousemove', onMouseMove);

     drag1.onmouseup = function() {
       document.removeEventListener('mousemove', onMouseMove);
       drag1.onmouseup = null;
     };

   };

   function enterDroppable(elem) {
     elem.style.background = 'pink';
   }

   function leaveDroppable(elem) {
     elem.style.background = '';
   }

   drag1.ondragstart = function() {
     return false;
   };
 </script>
</body>
</html>