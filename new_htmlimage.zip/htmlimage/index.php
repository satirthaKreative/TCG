<!DOCTYPE html>
<html>
<head>
	<style>
		#canvas{
		  width: 572px;
		  height: 400px;
		  margin: 0 auto;
		}
	</style>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	<script src="https://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
	<script src="html2canvas.js"></script>
	<title>Image Download</title>
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-sm-6 col-sm-offset-3">
				<form id="screen_sort">
				  <div class="data_canvas">
				  	<div class="form-group">
				  	  <label for="exampleInputEmail1">Email address</label>
				  	  <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
				  	</div>
				  	<div class="form-group">
				  	  <label for="exampleInputPassword1">Password</label>
				  	  <input type="password" class="form-control" value="data test" id="exampleInputPassword1" placeholder="Password">
				  	</div>
				  	<div class="form-group form-check">
				  	  <input type="checkbox" class="form-check-input" id="exampleCheck1">
				  	  <label class="form-check-label" for="exampleCheck1">Check me out</label>
				  	</div>
				  </div>
				  <button type="button" class="btn btn-primary" id="capture">Submit</button>
				</form>
			</div>
			<div class="col-sm-12">
				<div id="canvas">
				  
				</div> 
				<div id="image">
				  
				</div> 
			</div>
		</div>
	</div>
	<script>
		
		$('#capture').click(function(){
		  html2canvas([document.getElementById('data_canvas')], {
		      onrendered: function (canvas) {
		          document.getElementById('canvas').appendChild(canvas);
		          var data = canvas.toDataURL('image/png');
		          // AJAX call to send `data` to a PHP file that creates an image from the dataURI string and saves it to a directory on the server

		          var image = new Image();
		          image.src = data;
		          document.getElementById('image').appendChild(image);
		      }
		  });
		});
	</script>
</body>
</html>