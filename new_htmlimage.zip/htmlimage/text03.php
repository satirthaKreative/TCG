<!DOCTYPE HTML>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	<script src="https://files.codepedia.info/files/uploads/iScripts/html2canvas.js"></script>
<style>
/*#div1 #drag1{
	background:transparent;
	border: none;
	font-size: 30px;
	color: #ededed;
	text-align: center;
}*/
/*#div1 #drag3{
	background:transparent;
	border: none;
	font-size: 15px;
	color: #ededed;
	text-align: center;
}*/
#div1 {
  width: 400px;
  height: 400px;
  padding: 10px;
  border: 1px solid #aaaaaa;
}
</style>
<script>
function allowDrop(ev) {
  ev.preventDefault();
}

function drag(ev) {
  ev.dataTransfer.setData("text", ev.target.id);
}


function drop(ev) {
  ev.preventDefault();
  var data = ev.dataTransfer.getData("text");
  ev.target.appendChild(document.getElementById(data));
}


</script>
</head>
<body>

<p>Satirtha Test:</p>
<div class="container">
	<div class="row">
		<div class="col-sm-8 ">
			<div id="html-content-holder">
				<div id="div1" ondrop="drop(event)" ondragover="allowDrop(event)" style="background-image: url('2.jpg');">
					<input type="text" id="drag1" draggable="true"  ondragstart="drag(event)" name=""/>	<br/>
					<textarea name="text" id="drag3" value="test" draggable="true" ondragstart="drag(event)" name=""></textarea>
					<img id="drag4" src="Birthday-Hat-PNG-Picture.png"  draggable="true"  ondragstart="drag(event)"  width="200" height="150" />
					<input type="text" id="drag2" draggable="true"  ondragstart="drag(event)" name="" /> <br>
				</div>
					
			</div>
		</div>
		<div class="col-sm-4">
			<!-- <img id="drag1" src="img_logo.gif" draggable="true" ondragstart="drag(event)" width="336" height="69">
 -->	
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<input id="btn-Preview-Image" type="button" value="Preview"/>
			<a id="btn-Convert-Html2Image" href="#">Download</a>
			<br/>
			<h3>Preview :</h3>
			<div id="previewImage">
			</div>
		</div>
	</div>
</div>
<script>
	$(document).ready(function(){

		
	var element = $("#html-content-holder"); // global variable
	var getCanvas; // global variable
	 
	    $("#btn-Preview-Image").on('click', function () {
	         html2canvas(element, {
	         onrendered: function (canvas) {
	                $("#previewImage").append(canvas);
	                getCanvas = canvas;
	             }
	         });
	    });

		$("#btn-Convert-Html2Image").on('click', function () {
	    var imgageData = getCanvas.toDataURL("image/png");

	    // Now browser starts downloading it instead of just showing it
	    var newData = imgageData.replace(/^data:image\/png/, "data:application/octet-stream");
	    $("#btn-Convert-Html2Image").attr("download", "my_data.png").attr("href", newData);
		});

	});

</script>

<script>
	$(function(){
		$("#drag1").keypress(function(event){
			$("#drag1").css("background", "transparent");
			$("#drag1").css("border", "none");
			$("#drag1").css("font-size", "30px");
			$("#drag1").css("color", "rgb(12, 162, 234)");
			$("#drag1").css("text-align", "center");
		});
		$("#drag2").keypress(function(event){
			$("#drag2").css("background", "transparent");
			$("#drag2").css("border", "none");
			$("#drag2").css("font-size", "30px");
			$("#drag2").css("color", "red");
			$("#drag2").css("text-align", "center");
		});
		$("#drag3").keypress(function(event){
			$("#drag3").css("background", "transparent");
			$("#drag3").css("border", "none");
			$("#drag3").css("font-size", "20px");
			$("#drag3").css("color", "#fff");
			$("#drag3").css("text-align", "center");
		});
		$("#drag3").change(function(event){
			$("#drag3").css("background", "transparent");
			$("#drag3").css("border", "none");
			$("#drag3").css("font-size", "18px");
			$("#drag3").css("color", "#fff");
			$("#drag3").css("text-align", "center");
		});
	});
</script>
<script>
   let currentDroppable = null;

   drag4.onmousedown = function(event) {

     let shiftX = event.clientX - drag4.getBoundingClientRect().left;
     let shiftY = event.clientY - drag4.getBoundingClientRect().top;

     drag4.style.position = 'absolute';
     drag4.style.zIndex = 1000;
     document.body.append(drag4);

     moveAt(event.pageX, event.pageY);

     function moveAt(pageX, pageY) {
       drag4.style.left = pageX - shiftX + 'px';
       drag4.style.top = pageY - shiftY + 'px';
     }

     function onMouseMove(event) {
       moveAt(event.pageX, event.pageY);

       drag4.hidden = true;
       let elemBelow = document.elementFromPoint(event.clientX, event.clientY);
       drag4.hidden = false;

       if (!elemBelow) return;

       let droppableBelow = elemBelow.closest('.droppable');
       if (currentDroppable != droppableBelow) {
         if (currentDroppable) { // null when we were not over a droppable before this event
           leaveDroppable(currentDroppable);
         }
         currentDroppable = droppableBelow;
         if (currentDroppable) { // null if we're not coming over a droppable now
           // (maybe just left the droppable)
           enterDroppable(currentDroppable);
         }
       }
     }

     document.addEventListener('mousemove', onMouseMove);

     drag4.onmouseup = function() {
       document.removeEventListener('mousemove', onMouseMove);
       drag4.onmouseup = null;
     };

   };

   function enterDroppable(elem) {
     elem.style.background = 'pink';
   }

   function leaveDroppable(elem) {
     elem.style.background = '';
   }

   drag4.ondragstart = function() {
     return false;
   };
 </script>
</body>
</html>