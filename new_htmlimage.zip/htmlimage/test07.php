<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Tesing Details</title>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <style>
  /* #draggable {  width: 20px; height: 32px;  } */
 /* #draggable1 {  width: 20px; height: 32px;  }
  #draggable2 {  width: 20px; height: 32px;  }*/
  .test .ui-widget-content{
    background: none;
    border: none;
    cursor: pointer;
  }
  .test .ui-widget-content img{
    width: 15px;
    bottom: 100%;
    position: absolute;
    left: 0;
  }
  </style>
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script src="https://files.codepedia.info/files/uploads/iScripts/html2canvas.js"></script>
  <script>
  $( function() {
    $( "#draggable" ).draggable();
    $( "#draggable1" ).draggable();
    $( "#draggable2" ).draggable();

    $("#draggable").find("input").keypress(function(){
      $("#draggable").find("input").css("background","transparent");
      $("#draggable").find("input").css("border","none");
      $("#draggable").find("input").css("color","#fff");
      $("#draggable").find("input").css("font-size","20px");
    });

    $("#draggable1").find("input").keypress(function(){
      $("#draggable1").find("input").css("background","transparent");
      $("#draggable1").find("input").css("border","none");
      $("#draggable1").find("input").css("color","#fff");
      $("#draggable1").find("input").css("font-size","20px");
    });

    $("#draggable2").find("textarea").keypress(function(){
      $("#draggable2").find("textarea").css("background","transparent");
      $("#draggable2").find("textarea").css("border","none");
      $("#draggable2").find("textarea").css("color","#fff");
      $("#draggable2").find("textarea").css("font-size","15px");
    });

  });
  </script>
  <script>
    $(document).ready(function(){

      
    var getCanvas; // global variable
     
        $("#btn-Preview-Image").on('click', function () {
          $("#draggable").css("background-color",'transparent');
          $("#draggable1").css("background-color",'transparent');
          $("#draggable2").css("background-color",'transparent');
          var element = $("section"); // global variable
          
             html2canvas(element, {
             onrendered: function (canvas) {
                    $("#previewImage").append(canvas);
                    getCanvas = canvas;
                 }
             });
        });

      $("#btn-Convert-Html2Image").on('click', function () {
        var imgageData = getCanvas.toDataURL("image/png");

        // Now browser starts downloading it instead of just showing it
        var newData = imgageData.replace(/^data:image\/png/, "data:application/octet-stream");
        $("#btn-Convert-Html2Image").attr("download", "my_data.png").attr("href", newData);
      });

    });

  </script>
</head>
<body>
<section class="test" style="background: url('3.webp');width: 500px;height: 300px;">
   
  <div id="draggable" class="ui-widget-content">
    <img src="move.png" alt="">
    <p><input type="text" name=""></p>
  </div>
  <div id="draggable1" class="ui-widget-content">
    <img src="move.png" alt="">
    <p><input type="text" name=""></p>
  </div>

   <div id="draggable2" class="ui-widget-content">
    <img src="move.png" alt="">
    <p><textarea name="" id=""></textarea></p>
  </div>
   
</section>
<div >
  <input type="text" value="text" name="">
  <input id="btn-Preview-Image" type="button" value="Preview"/>
  <a id="btn-Convert-Html2Image" href="#">Download</a>
  <br/>
  <h3>Preview :</h3>
  <div id="previewImage">
        
</div>
</div>
</body>
</html>